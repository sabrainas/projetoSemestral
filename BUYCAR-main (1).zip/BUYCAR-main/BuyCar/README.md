# DevClass 001: Projeto DevCar
Repositório do nosso devClass de HTML e CSS para iniciantes.

## Recursos: 
Template utilizado neste projeto
https://www.figma.com/file/zEdDGF7hn1AOmZHfI04Sz6/devClass_001_HTML_CSS?node-id=0%3A1

Domine o FlexBox com o FlexboxFroggy
https://flexboxfroggy.com/

Lista das transparências para adicionar opacidade a uma cor hexadecimal:
https://gist.github.com/lucianodiisouza/bad9ee2e73bfd33fd6ca4a601fabf6c3

Link para a landing page já pronta:
https://devclass-001.netlify.app/

Template para a página de login:
https://www.youtube.com/watch?v=IphMgLFPR6w&t=20s
